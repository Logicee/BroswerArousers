/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


window.onload = function () {

    getAllTeams();
    // add event handler for selections on the table
    document.querySelector("#table").addEventListener("click", handleRowClick);
    document.querySelector("#clrSelection").addEventListener("click", clearSelections);
    document.querySelector("#stats").addEventListener("click",viewStats);
    docuement.querySelector("#payout").addEventListener("click",viewPayout);
    document.querySelector("#recap").addEventListener("click",viewRecap);
   
    
    
};
function handleRowClick(e){
    clearSelections();
    e.target.parentElement.classList.add("highlighted");
    fillTheTeam();
    console.log(e);
let id= e.target.parentElement.firstChild.innerHTML;
//console.log(id);
    
}
function clearTheTable(){
 let theTable = document.querySelector("table");
 theTable.innerHTML-"";
}
function viewStats()
{clearTheTable();
   //pull game stats from db 
}
function viewPayout(){
    clearTheTable();
    //pull payout stats from db
}
function viewRecap(){
    clearTheTable();
    //pull recap stats from db
}
function clearSelections(){
      let trs = document.querySelectorAll("tr");
    for (let i = 0; i < trs.length; i++) {
        trs[i].classList.remove("highlighted");
    }
   
}
function getAllTeams()
        {  let url = "api/getAllTeams.php"; // file name or server-side process name
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0) {
                alert("oh no...");
            } else {
                buildTable(xmlhttp.responseText);
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();}
function buildTable(text) {
  
    let arr = JSON.parse(text); // get JS Objects
     let theTable = document.selectElementByID("table");
    let html = theTable.querySelector("tr").innerHTML;
    console.log(arr.length + "array length");
    for (let i = 0; i < arr.length; i++) {
        let row = arr[i];
        html += "<tr>";
        console.log(row);
        html += "<td>" + row.teamID + "</td>";
        html += "<td>" + row.teamName + "</td>";
        html += "<td>" + row.playerCount + "</td>";
        html += "</tr>";
    }
    lastTeamID = arr[arr.length - 1].teamID;
    theTable.innerHTML = html;
    
}
function buildTable2(text){
    let arr = JSON.parse(text); // get JS Objects
    let theTable = document.selectElementByID("table2");
    let html = theTable.querySelector("tr").innerHTML;
    console.log(arr.length + "array length");
    for (let i = 0; i < arr.length; i++) {
        let row = arr[i];
        html += "<tr>";
        console.log(row);
        
        html += "<td>" + rowFName + "</td>";
        html += "<td>" + row.LName + "</td>";
        html += "<td>" + row.province + "</td>";
        html += "<td>" + row.homeTown + "</td>";
        html += "<td>" + row.ID + "</td>";
        html += "</tr>";
    }
    lastTeamID = arr[arr.length - 1].teamID;
    theTable.innerHTML = html;
}
function fillTheTeam(text){
    let url="api/getAllPlayers.php";
    let xmlhttp= new XMLHttpRequest();
    xmlhttp.onreadystatechange= function(){
        if(xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0) {
                alert("oh no...");
            } else {
                buildTable2(xmlhttp.responseText);
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();}
    
    
