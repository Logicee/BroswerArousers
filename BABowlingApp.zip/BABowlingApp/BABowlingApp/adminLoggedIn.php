<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */session_start();
/* echo $_SESSION['email'];
echo $_SESSION['password'];

echo"LOGGED IN";
VERIFY LOGIN INFO FROM INPUTS AGAINST CURRENT USERS AND THEN FORWARD */
 header('Location: adminIndex.php');