<?php

$projectRoot = $_SERVER['DOCUMENT_ROOT'] . '/BABowlingApp';
require_once 'dbconnection.php';
require_once ($projectRoot . '/entity/Team.php');

class TeamAccessor {

//    private $getGamesByStatusStatementString = "select * from game where gameStateID IN(\"AVAILABLE\",\"INPROGRESS\")";
    private $getByIDStatementString = "select * from cars where Number = :number";
    private $getByIDStatement = NULL;
    private $conn = NULL;

//    private $getGamesByStatusStatement = NULL;

    public function __construct() {
        $cm = new dbConnect();

        $this->conn = $cm->connectToDB();
        if (is_null($this->conn)) {
            throw new Exception("no connection");
        }
        $this->getByIDStatement = $this->conn->prepare($this->getByIDStatementString);
        if (is_null($this->getByIDStatement)) {
            throw new Exception("bad statement: '" . $this->getAllStatementString . "'");
        }
    }

    private function getTeamsByQuery($selectString) {
        $result = [];

        try {
            $stmt = $this->conn->prepare($selectString);
            $stmt->execute();
            $dbresults = $stmt->fetchAll(PDO::FETCH_ASSOC);

            foreach ($dbresults as $r) {
                $teamID = $r['teamID'];
                $teamName = $r['teamName'];
                $playerCount = $r['Total_players'];
                $obj = new Team($teamID, $teamName, $playerCount);
                array_push($result, $obj);
            }
        } catch (Exception $e) {
            $result = [];
        } finally {
            if (!is_null($stmt)) {
                $stmt->closeCursor();
            }
        }

        return $result;
    }

    public function getAllTeams() {
        return $this->getTeamsByQuery("select t.teamName, p.teamID, count(*) as Total_players from team t, player p where t.teamID = p.teamID group by t.teamID");
    }

    public function insertItem($item) {
        $success = false;

        $teamID = $item->getTeamID();
        $teamName = $item->getTeamName();
        $earnings = $item->getPlayerCount();

        try {
            $this->insertStatement->bindParam(":teamID", $teamID);
            $this->insertStatement->bindParam(":teamName", $teamName);
            $this->insertStatement->bindParam(":earnings", $earnings);
            $success = $this->insertStatement->execute(); // this doesn't mean what you think it means
        } catch (PDOException $e) {
            $success = false;
        } finally {
            if (!is_null($this->insertStatement)) {
                $this->insertStatement->closeCursor();
            }
            return $success;
        }
    }

}

//end class

