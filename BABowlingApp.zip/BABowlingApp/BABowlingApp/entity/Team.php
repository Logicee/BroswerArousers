<?php

class Team implements JsonSerializable {
    private $teamID;
    private $teamName;
    private $playerCount;
//    private $players;
    
    public function __construct($teamID, $teamName, $playerCount) {
        $this->teamID = $teamID;
        $this->teamName = $teamName;
        $this->playerCount = $playerCount;
//      $this->players = $players;
    }
   

    public function getTeamID() {
        return $this->teamID;
    }

    public function getTeamName() {
        return $this->teamName;
    }

    public function getPlayerCount() {
        return $this->playerCount;
    }
    
//    public function getPlayers() {
//        return $this->players;
//    }
    
//    public function incrementEarnings($amount){
//        $this->earnings += $amount;
//    }

    public function jsonSerialize() {
        return get_object_vars($this);
    }
}

