<!DOCTYPE html>

 <html>
    <head>
        <meta charset="UTF-8">
        <title>Scorekeeper Log</title>
 <link rel="stylesheet" href="bowling1.css"/>
        <script><?php include 'mainjava.js'; ?></script></head><body>
 <h1>Please enter a username and password</h1>
 <img src="bowling.jpg" alt="Bowling Ball" width="500" height="400" class="pic">
 <form action="ScoreKeeperVerify.php" method="POST">
     Email Address: <input name="email" type="text" required>
    Password: <input name="pass" type="text" required>
     <button type="submit" name="Login" >Login now</button>
     <button type="submit" name="Create">Create Account</button>
 </form>
    
              </body>
 </html>