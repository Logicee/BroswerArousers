<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 
echo $_SESSION['email'];
echo $_SESSION['password'];
echo"CREATE THIS USER";
CHECK THE INPUTS ARE VALID AND THEN ADD A USER TO THE SYSTEM. THEN FORWARD TO SCOREKEEPER INDEX
 * 
 */
header('Location: scheduledGames.php');