<?php
$projectRoot = filter_input(INPUT_SERVER, 'DOCUMENT_ROOT') . '/BABowlingApp';
require_once ($projectRoot . '/accessors/PlayerAccessor.php');
$teamID= "1";
try {
    $mia = new PlayerAccessor();
    $results = $mia->getTeamPlayers($teamID); // these are objects
    $results = json_encode($results, JSON_NUMERIC_CHECK);
    echo $results;
} catch (Exception $e) {
    echo "ERROR " . $e->getMessage();
}